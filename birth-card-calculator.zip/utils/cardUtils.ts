import { Suit } from '../types';

export const getSuitColor = (suit: Suit): 'text-red-400' | 'text-gray-300' | 'text-purple-400' => {
  switch (suit) {
    case Suit.Hearts:
    case Suit.Diamonds:
      return 'text-red-400';
    case Suit.Clubs:
    case Suit.Spades:
      return 'text-gray-300';
    case Suit.Joker:
      return 'text-purple-400';
    default:
      return 'text-gray-300';
  }
};
