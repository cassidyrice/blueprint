import React, { useState } from 'react';
import { Card } from '../types';
import CardDisplay from './CardDisplay';
import { GoogleGenAI } from '@google/genai';
import MarkdownRenderer from './MarkdownRenderer';
import { archetypeSystemData } from '../services/archetypeData';
import { mapCardToKey } from '../services/cardService';

interface KarmaCardResultProps {
  birthCard: Card;
  personaCard: Card | null;
  negativeKarmaCard: Card | null;
  positiveKarmaCard: Card | null;
  onReset: () => void;
  onNext: () => void;
}

interface GeminiState {
    analysis: string | null;
    isLoading: boolean;
    error: string | null;
}

const initialGeminiState: GeminiState = {
    analysis: null,
    isLoading: false,
    error: null
};

const KarmaCardDisplay: React.FC<{
    card: Card | null;
    birthCard: Card;
    personaCard: Card | null;
    title: string;
    titleColor: string;
    description: string;
    type: 'Negative' | 'Positive';
}> = ({ card, birthCard, personaCard, title, titleColor, description, type }) => {
    const [geminiState, setGeminiState] = useState<GeminiState>(initialGeminiState);

    const getAnalysis = async () => {
        if (!card) return;

        setGeminiState({ isLoading: true, error: null, analysis: null });

        const cardKey = mapCardToKey(card);
        const cardDetails = archetypeSystemData.cards[cardKey];
        if (!cardDetails) {
            setGeminiState({ isLoading: false, error: "Could not find archetype details for this card.", analysis: null });
            return;
        }
        
        const promptType = type === 'Negative' ? 'karmic challenge or debt' : 'karmic gift or reward';
        const focusAspect = type === 'Negative' ? cardDetails.challenges : cardDetails.strengths;
        const taskInstruction = type === 'Negative' 
            ? 'Explain what this energy represents as a difficult pattern or lesson the user needs to confront and resolve. Interweave the potential pitfalls with the path to overcoming them.'
            : 'Explain what this energy represents as an innate talent or a positive attribute earned from past actions. Interweave the strengths with the responsibility of using this gift wisely, and the potential for it to be misused if taken for granted.';

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `
                You are an expert card reader with a direct, no-nonsense style. Your analysis is plain-spoken, serious, and insightful, focusing on karmic patterns.

                A user's profile is:
                - **Core Identity (Birth Card):** ${birthCard.name}
                - **Public Persona Card:** ${personaCard ? personaCard.name : 'Unknown'}

                They are examining their **${type} Karma Card**: the ${card.name}.

                **Card Data:**
                - Archetype: ${cardDetails.archetype}
                - Core Nature: ${cardDetails.core_nature}
                - Key Aspect: ${focusAspect}

                **Task:**
                Provide a direct, serious analysis of this card as a **${promptType}**, specifically for a person with this identity/persona combination. ${taskInstruction} Do not separate into "positive" and "negative" sections. The tone should be straightforward and focused on the core lesson. Format using simple markdown.
            `;
            
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
            });
            setGeminiState({ isLoading: false, error: null, analysis: response.text });
        } catch (err) {
            console.error("Gemini API call failed:", err);
            setGeminiState({ isLoading: false, error: "An error occurred during the analysis. Please try again later.", analysis: null });
        }
    };

    return (
        <div className="flex flex-col items-center">
            <h3 className={`text-xl font-semibold ${titleColor} mb-3`}>{title}</h3>
            <CardDisplay card={card} />
            <p className="mt-1 text-sm text-gray-400 max-w-xs">{description}</p>
            
            {/* Gemini Section */}
            {card && (
                <div className="mt-4 w-full max-w-sm text-center">
                    {!geminiState.analysis && !geminiState.isLoading && (
                        <button 
                            onClick={getAnalysis}
                            className="bg-gray-700 text-gray-300 font-bold py-2 px-4 rounded-lg hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-gray-500 transition-all duration-300 text-sm"
                        >
                            Go Deeper
                        </button>
                    )}
                    {geminiState.isLoading && <p className="text-gray-400 text-sm">Analyzing...</p>}
                    {geminiState.error && <p className="text-red-400 text-sm">{geminiState.error}</p>}
                    {geminiState.analysis && (
                        <div className="mt-4 bg-gray-900/50 p-4 rounded-lg border border-gray-700 animate-fade-in text-left">
                           <h4 className="text-lg font-bold text-center mb-2 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">Deeper Analysis</h4>
                           <MarkdownRenderer content={geminiState.analysis} />
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

const KarmaCardResult: React.FC<KarmaCardResultProps> = ({ birthCard, personaCard, negativeKarmaCard, positiveKarmaCard, onReset, onNext }) => {
  return (
    <div className="w-full max-w-7xl mx-auto animate-gentle-slide-fade-in">
      <div className="bg-gray-800 bg-opacity-50 backdrop-blur-sm p-4 sm:p-8 rounded-2xl shadow-2xl border border-gray-700 text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-8">
          Karmic Ledger
        </h2>
        
        <div className="flex flex-col lg:flex-row justify-center items-center lg:items-start gap-8 lg:gap-12">
            
            <div className="animate-gentle-slide-fade-in opacity-0" style={{ animationDelay: '300ms' }}>
                <KarmaCardDisplay
                    card={negativeKarmaCard}
                    birthCard={birthCard}
                    personaCard={personaCard}
                    title="Karmic Liability"
                    titleColor="text-red-400"
                    description="A challenge or pattern you're here to resolve. A debt to be paid. Paying attention is the first installment."
                    type="Negative"
                />
            </div>
            
            <div className="flex flex-col items-center animate-gentle-slide-fade-in opacity-0 order-first lg:order-none" style={{ animationDelay: '100ms' }}>
                <h3 className="text-xl font-semibold text-gray-300 mb-3">Your Birth Card</h3>
                <CardDisplay card={birthCard} />
                 <p className="mt-1 text-sm text-gray-400 max-w-xs">Your core identity. The entity navigating this karmic balance.</p>
            </div>
            
            <div className="animate-gentle-slide-fade-in opacity-0" style={{ animationDelay: '500ms' }}>
                <KarmaCardDisplay
                    card={positiveKarmaCard}
                    birthCard={birthCard}
                    personaCard={personaCard}
                    title="Karmic Asset"
                    titleColor="text-green-400"
                    description="A talent or advantage you've earned. A gift. Don't squander it."
                    type="Positive"
                />
            </div>

        </div>
        
        <div className="mt-12 flex flex-col items-center gap-4">
            <button
                onClick={onNext}
                className="w-full max-w-md bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:from-purple-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 transition-all duration-300 transform hover:scale-105 active:scale-95"
            >
                Next: Chart Your Life Map
            </button>
            <button
              onClick={onReset}
              className="w-full max-w-md text-gray-400 font-medium py-2 px-4 rounded-lg hover:bg-gray-700/50 hover:text-white focus:outline-none transition-all duration-300 text-sm"
            >
              Start Over
            </button>
        </div>
      </div>
    </div>
  );
};

export default KarmaCardResult;