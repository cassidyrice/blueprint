import React, { useState } from 'react';

interface BirthCardFormProps {
  onSubmit: (month: number, day: number) => void;
  isProcessing: boolean;
  title: string;
  subtitle: string;
  submitText: string;
  loadingText: string;
}

const BirthCardForm: React.FC<BirthCardFormProps> = ({ onSubmit, isProcessing, title, subtitle, submitText, loadingText }) => {
  const [month, setMonth] = useState('');
  const [day, setDay] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const monthNum = parseInt(month, 10);
    const dayNum = parseInt(day, 10);

    if (isNaN(monthNum) || monthNum < 1 || monthNum > 12) {
      setError('Please enter a valid month (1-12).');
      return;
    }
    if (isNaN(dayNum) || dayNum < 1 || dayNum > 31) {
      setError('Please enter a valid day (1-31).');
      return;
    }
    
    // A leap year for validation purposes
    const daysInMonth = new Date(2024, monthNum, 0).getDate();
    if (dayNum > daysInMonth) {
      setError(`Invalid date. Month ${monthNum} only has ${daysInMonth} days.`);
      return;
    }

    setError(null);
    onSubmit(monthNum, dayNum);
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-gray-800 bg-opacity-50 backdrop-blur-sm p-6 sm:p-8 rounded-2xl shadow-2xl border border-gray-700">
        <h2 
          style={{ animationDelay: '100ms' }}
          className="text-2xl sm:text-3xl font-bold text-center mb-2 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 animate-gentle-slide-fade-in opacity-0"
        >
          {title}
        </h2>
        <p 
          style={{ animationDelay: '200ms' }}
          className="text-center text-gray-400 mb-6 animate-gentle-slide-fade-in opacity-0"
        >
          {subtitle}
        </p>
        <form onSubmit={handleSubmit}>
          <div 
            style={{ animationDelay: '300ms' }}
            className="flex flex-col sm:flex-row sm:space-x-4 space-y-4 sm:space-y-0 mb-6 animate-gentle-slide-fade-in opacity-0"
          >
            <div className="flex-1">
              <label htmlFor="month" className="block text-sm font-medium text-gray-300 mb-2">Month</label>
              <input
                id="month"
                type="number"
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                placeholder="e.g., 7"
                min="1"
                max="12"
                disabled={isProcessing}
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all duration-300"
              />
            </div>
            <div className="flex-1">
              <label htmlFor="day" className="block text-sm font-medium text-gray-300 mb-2">Day</label>
              <input
                id="day"
                type="number"
                value={day}
                onChange={(e) => setDay(e.target.value)}
                placeholder="e.g., 14"
                min="1"
                max="31"
                disabled={isProcessing}
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all duration-300"
              />
            </div>
          </div>
          {error && <p className="text-red-400 text-center text-sm mb-4 animate-pop-in">{error}</p>}
          <button
            style={{ animationDelay: '400ms' }}
            type="submit"
            disabled={isProcessing}
            className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:from-purple-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 transition-all duration-300 transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed animate-gentle-slide-fade-in opacity-0"
          >
            {isProcessing ? loadingText : submitText}
          </button>
        </form>
      </div>
    </div>
  );
};

export default BirthCardForm;