import React, { useState } from 'react';
import { CardArchetype } from '../types';
import { mapKeyToCard } from '../services/cardService';
import { archetypeSystemData } from '../services/archetypeData';
import ArchetypeDetailView from './ArchetypeDetailView';


const CardLibrary: React.FC = () => {
  const [selectedCardKey, setSelectedCardKey] = useState<string | null>(null);
  
  const cardData = archetypeSystemData;
  const cardKeys = Object.keys(cardData.cards);

  if (selectedCardKey) {
    const card = mapKeyToCard(selectedCardKey);
    const details = cardData.cards[selectedCardKey];
    return <ArchetypeDetailView card={card} cardDetails={details} onBack={() => setSelectedCardKey(null)} context="Library" />;
  }

  return (
    <div className="w-full max-w-7xl mx-auto animate-fade-in">
        <div className="bg-gray-800 bg-opacity-50 backdrop-blur-sm p-4 sm:p-8 rounded-2xl shadow-2xl border border-gray-700 text-center">
            <h2 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-8">
                The Archives
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto mb-8 -mt-4">
                A raw data dump of all 52 archetypes. Click any entry for a full dossier.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                {cardKeys.map((key, index) => {
                    if (key === 'joker') return null; // Exclude Joker for now if it doesn't fit the archetype system
                    const cardInfo = cardData.cards[key];
                    return (
                        <button
                            key={key}
                            onClick={() => setSelectedCardKey(key)}
                            className="bg-gray-900 border border-gray-700 rounded-lg p-4 h-24 flex flex-col items-center justify-center text-center hover:bg-gray-700 hover:border-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all duration-200 transform hover:-translate-y-1"
                            style={{ animation: `gentleSlideFadeIn 0.5s ease-out ${index * 0.02}s forwards`, opacity: 0}}
                            aria-label={`View details for ${cardInfo.name}`}
                        >
                            <span className="font-semibold text-base text-gray-200">{cardInfo.name}</span>
                        </button>
                    )
                })}
            </div>
        </div>
    </div>
  );
};

export default CardLibrary;
