import React, { useState } from 'react';
import { Card } from '../types';
import { mapAbbreviationToCard } from '../services/cardService';
import CardDisplay from './CardDisplay';
import { InfoIcon } from './InfoIcon';
import LifePathModal from './LifePathModal';
import { lifePathStageInfo } from '../services/lifePathStageInfo';


interface LifePathResultProps {
  birthCard: Card;
  personaCard: Card | null;
  path: { [key: string]: string } | null;
  onReset: () => void;
}

const LifePathResult: React.FC<LifePathResultProps> = ({ birthCard, personaCard, path, onReset }) => {
  const [selectedStage, setSelectedStage] = useState<string | null>(null);

  const stages = path ? [
    'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 
    'Neptune', 'Pluto', 'Result', 'Cosmic Lesson', 'Cosmic Moon', 'Transformed Self'
  ] : [];

  const lifePathCards = stages.map(stage => ({
    name: stage,
    card: mapAbbreviationToCard(path![stage]),
  }));

  const openModal = (stageName: string) => {
      setSelectedStage(stageName);
  }

  const closeModal = () => {
      setSelectedStage(null);
  }

  const selectedStageInfo = selectedStage ? {
      stageName: selectedStage,
      card: lifePathCards.find(c => c.name === selectedStage)?.card,
      info: lifePathStageInfo[selectedStage]
  } : null;
  if(selectedStage === 'Birth Card' && selectedStageInfo) {
    selectedStageInfo.card = birthCard;
  }

  return (
    <div className="w-full max-w-7xl mx-auto animate-gentle-slide-fade-in">
      <div className="bg-gray-800 bg-opacity-50 backdrop-blur-sm p-4 sm:p-8 rounded-2xl shadow-2xl border border-gray-700 text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">
          Life Map Charted
        </h2>
        <p className="text-gray-400 max-w-3xl mx-auto mt-2 mb-8">Each card represents a core theme or challenge in a specific domain of your life. Your Birth Card is the sun; these are the planets in its orbit. Click the info icon on any card for a detailed briefing.</p>


        {/* Birth Card Section */}
        <div className="mb-12" style={{ animation: 'gentleSlideFadeIn 0.7s ease-out forwards', opacity: 0 }}>
          <div className="flex justify-center items-center gap-2 mb-3">
             <h3 className="text-xl font-semibold text-gray-300">Birth Card</h3>
             <button onClick={() => openModal('Birth Card')} className="text-purple-400 hover:text-purple-300 transition-colors" aria-label="Show info for Birth Card">
                <InfoIcon className="w-6 h-6" />
             </button>
          </div>
          <div className="flex justify-center">
            <CardDisplay card={birthCard} />
          </div>
        </div>

        {path ? (
          <>
            {/* Life Path Spread Section */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-4 gap-y-8">
              {lifePathCards.map((item, index) => (
                <div 
                  key={item.name} 
                  className="flex flex-col items-center animate-gentle-slide-fade-in opacity-0"
                  style={{ animationDelay: `${300 + index * 50}ms` }}
                >
                  <div className="flex items-center gap-1 mb-2">
                    <h4 className="text-base font-semibold text-purple-300 whitespace-nowrap">{item.name}</h4>
                     <button onClick={() => openModal(item.name)} className="text-purple-400 hover:text-purple-300 transition-colors" aria-label={`Show info for ${item.name}`}>
                        <InfoIcon className="w-5 h-5" />
                     </button>
                  </div>
                  <CardDisplay card={item.card} size="small" />
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-lg text-gray-400">The Life Path spread is not available for the Joker card.</p>
        )}
        
        <button
          onClick={onReset}
          className="w-full max-w-md mx-auto mt-12 bg-gray-700 text-gray-300 font-bold py-3 px-4 rounded-lg hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500 transition-all duration-300"
        >
          Start Over
        </button>
      </div>

      {selectedStageInfo && selectedStageInfo.card && selectedStageInfo.info && (
        <LifePathModal
            isOpen={!!selectedStage}
            onClose={closeModal}
            birthCard={birthCard}
            personaCard={personaCard}
            card={selectedStageInfo.card}
            stageInfo={selectedStageInfo.info}
        />
      )}
    </div>
  );
};

export default LifePathResult;
