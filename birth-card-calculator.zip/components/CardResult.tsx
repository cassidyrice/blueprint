import React from 'react';
import { Card } from '../types';

interface CardResultProps {
  card: Card;
  onShowMeaning: () => void;
  onReset: () => void;
  title?: string;
  subtitle?: string;
  onNext?: () => void;
  nextText?: string;
}

const CardResult: React.FC<CardResultProps> = ({ card, onShowMeaning, onReset, title, subtitle, onNext, nextText }) => {
  return (
    <div className="w-full max-w-md mx-auto animate-gentle-slide-fade-in">
      <div className="bg-gray-800 bg-opacity-50 backdrop-blur-sm p-6 sm:p-8 rounded-2xl shadow-2xl border border-gray-700 text-center">
        <h2 
          style={{ animationDelay: '100ms' }}
          className="text-2xl sm:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 animate-gentle-slide-fade-in opacity-0"
        >
          {title || 'Your Birth Card'}
        </h2>
        
        <h3 
          style={{ animationDelay: '300ms' }}
          className="text-4xl sm:text-5xl font-serif font-bold text-gray-100 my-8 animate-gentle-slide-fade-in opacity-0"
        >
          {card.name}
        </h3>
        
        <p 
          style={{ animationDelay: '400ms' }}
          className="text-gray-400 mb-8 animate-gentle-slide-fade-in opacity-0"
        >
          {subtitle || "This card represents your core personality and life's purpose."}
        </p>

        <div 
          style={{ animationDelay: '500ms' }}
          className="space-y-4 animate-gentle-slide-fade-in opacity-0"
        >
          {onNext && nextText && (
             <button
                onClick={onNext}
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:from-purple-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 transition-all duration-300 transform hover:scale-105 active:scale-95"
              >
                {nextText}
              </button>
          )}
          <button
            onClick={onShowMeaning}
            className="w-full bg-gray-700/50 border border-gray-600 text-gray-300 font-bold py-3 px-4 rounded-lg hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500 transition-all duration-300"
          >
            Go Deeper
          </button>
          <button
            onClick={onReset}
            className="w-full text-gray-400 font-medium py-2 px-4 rounded-lg hover:bg-gray-700/50 hover:text-white focus:outline-none transition-all duration-300 text-sm"
          >
            Start Over
          </button>
        </div>
      </div>
    </div>
  );
};

export default CardResult;
