import React, { useState } from 'react';
import { Card, CardArchetype } from '../types';
import CardDisplay from './CardDisplay';
import { GoogleGenAI } from '@google/genai';
import MarkdownRenderer from './MarkdownRenderer';

const Tag: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="inline-block bg-gray-700 rounded-full px-3 py-1 text-sm font-semibold text-gray-300 mr-2 mb-2 transition-colors hover:bg-gray-600">
    #{children}
  </span>
);

const DetailSection: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className = '' }) => (
  <div className={`mb-6 ${className}`}>
    <h4 className="text-xl font-bold text-purple-300 mb-3 border-b-2 border-purple-800 pb-2">{title}</h4>
    <div className="text-gray-300 text-base leading-relaxed">{children}</div>
  </div>
);

interface ArchetypeDetailViewProps {
  card: Card;
  cardDetails: CardArchetype;
  onBack: () => void;
  context: 'Birth Card' | 'PRC' | 'Library';
  birthCard?: Card | null;
}

const ArchetypeDetailView: React.FC<ArchetypeDetailViewProps> = ({ card, cardDetails, onBack, context, birthCard }) => {
    const [analysis, setAnalysis] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const getAnalysis = async () => {
        setIsLoading(true);
        setError(null);
        setAnalysis(null);

        const getContextDescription = () => {
            switch (context) {
                case 'Birth Card':
                    return "the user's core identity and personality (their Birth Card).";
                case 'PRC':
                    const birthCardInfo = birthCard ? `The user's core identity (Birth Card) is the **${birthCard.name}**. ` : '';
                    return `${birthCardInfo}This card represents the user's **Persona Card (PRC)**. The Persona Card is the "other half" of a person's core identity. It represents the mask they wear, how the world perceives them, and the primary way they channel their core energy into tangible action and value.`;
                case 'Library':
                    return "the card's general archetypal energy.";
                default:
                    return "the card's archetypal energy.";
            }
        }

        const getTaskDescription = () => {
            if (context === 'PRC' && birthCard) {
                return `Provide a concise, interwoven analysis of this card's role as a Persona Card for someone with a **${birthCard.name}** Birth Card. Explain how this energy functions as a public-facing persona for that specific core identity. How does it interact with the world? What are its strengths and weaknesses when used as a "mask" to channel the ${birthCard.name}'s energy? Be direct and serious. Do not use separate "high side" and "low side" sections. Instead, discuss how the positive traits can manifest and how they can turn into the negative traits if not managed. Format your response using simple markdown (paragraphs and bolding).`;
            }
            if (context === 'PRC') {
                 return `Provide a concise, interwoven analysis of this card's role as a Persona Card. Explain how this energy functions as a public-facing persona. How does it interact with the world? What are its strengths and weaknesses when used as a "mask"? How does it serve as the vehicle for expressing a deeper, core identity? Be direct and serious. Do not use separate "high side" and "low side" sections. Instead, discuss how the positive traits can manifest and how they can turn into the negative traits if not managed. Format your response using simple markdown (paragraphs and bolding).`;
            }
            return `Provide a concise, interwoven analysis of this card in the context provided. Do not use separate "high side" and "low side" sections. Instead, discuss how the positive traits can manifest and how they can turn into the negative traits if not managed. Explain the core dynamic of this card's energy in a direct and serious tone. Frame the entire interpretation through the lens of the provided context. Format your response using simple markdown (paragraphs and bolding).`;
        }


        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `
                You are an expert card reader with a direct, no-nonsense style. Your analysis is plain-spoken, serious, and insightful, avoiding mystical fluff.

                A user wants an analysis of the ${cardDetails.name}.

                **Card Data:**
                - Archetype: ${cardDetails.archetype}
                - Core Nature: ${cardDetails.core_nature}
                - Strengths: ${cardDetails.strengths}
                - Challenges: ${cardDetails.challenges}

                **Context:** ${getContextDescription()}

                **Task:**
                ${getTaskDescription()}
            `;

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
            });

            setAnalysis(response.text);

        } catch (err) {
            console.error("Gemini API call failed:", err);
            setError("An error occurred during the analysis. Please try again later.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="w-full max-w-5xl mx-auto animate-gentle-slide-fade-in">
            <div className="bg-gray-800 bg-opacity-70 backdrop-blur-md p-6 sm:p-8 rounded-2xl shadow-2xl border border-gray-700">
                <button onClick={onBack} className="mb-6 bg-gray-700 text-gray-300 font-bold py-2 px-4 rounded-lg hover:bg-gray-600 transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-purple-500">&larr; Back</button>
                <div className="text-center mb-8">
                    <h2 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">
                        {cardDetails.name}
                    </h2>
                     <p className="text-xl sm:text-2xl font-semibold text-gray-300 mt-1">{cardDetails.archetype}</p>
                </div>

                <div className="flex flex-col md:flex-row gap-8">
                    <div className="flex-shrink-0 mx-auto md:mx-0">
                         <CardDisplay card={card} />
                    </div>
                    <div className="flex-1 md:w-2/3">
                        <DetailSection title="Core Nature">
                            <p>{cardDetails.core_nature}</p>
                        </DetailSection>
                         <DetailSection title="Personality">
                            <p>{cardDetails.personality}</p>
                        </DetailSection>
                    </div>
                </div>

                 <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                     <DetailSection title="Strengths"><p>{cardDetails.strengths}</p></DetailSection>
                     <DetailSection title="Challenges"><p>{cardDetails.challenges}</p></DetailSection>
                     <DetailSection title="Life Approach"><p>{cardDetails.life_approach}</p></DetailSection>
                     <DetailSection title={cardDetails.in_domain_title}><p>{cardDetails.in_domain_description}</p></DetailSection>
                     <DetailSection title="Shadow Keywords" className="md:col-span-2">
                        <div className="flex flex-wrap">
                            {cardDetails.shadow_keywords.map(k => <Tag key={k}>{k}</Tag>)}
                        </div>
                     </DetailSection>
                 </div>

                 {/* Gemini Section */}
                <div className="mt-8 pt-6 border-t border-gray-700">
                    <h3 className="text-2xl font-bold text-center mb-4 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">Deeper Analysis</h3>
                    
                    {!analysis && !isLoading && (
                        <div className="text-center animate-fade-in">
                            <p className="text-gray-400 mb-4 max-w-2xl mx-auto">{`Request a direct, tactical analysis of the ${cardDetails.archetype} archetype within the current context.`}</p>
                            <button 
                                onClick={getAnalysis} 
                                disabled={isLoading} 
                                className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:from-purple-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 transition-all duration-300 transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Go Deeper
                            </button>
                        </div>
                    )}

                    {isLoading && (
                        <div className="flex justify-center items-center p-8 animate-fade-in">
                            <svg className="animate-spin h-8 w-8 text-purple-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <p className="ml-4 text-gray-400 text-lg">Compiling data...</p>
                        </div>
                    )}

                    {error && <p className="text-red-400 text-center p-4 bg-red-900/20 rounded-lg">{error}</p>}
                    
                    {analysis && (
                        <div className="mt-4 bg-gray-900/50 p-6 rounded-lg border border-gray-700 animate-fade-in">
                            <MarkdownRenderer content={analysis} />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};


export default ArchetypeDetailView;