import React, { useState, useCallback, useEffect } from 'react';
import BirthCardForm from './BirthCardForm';
import CardResult from './CardResult';
import ArchetypeDetailView from './ArchetypeDetailView';
import { Card, CardArchetype } from '../types';
import { cardData } from '../services/cardData';
import { mapNameToCard, mapCardToKey } from '../services/cardService';
import { archetypeSystemData } from '../services/archetypeData';

enum ViewState {
  FORM,
  RESULT,
  MEANING,
}

interface PrcLookupProps {
    birthDate: { month: number; day: number } | null;
    birthCard: Card | null;
    onComplete: (card: Card) => void;
    onStartOver: () => void;
}

const PrcLookup: React.FC<PrcLookupProps> = ({ birthDate, birthCard, onComplete, onStartOver }) => {
  const [viewState, setViewState] = useState<ViewState>(ViewState.FORM);
  const [resultCard, setResultCard] = useState<Card | null>(null);
  const [cardDetails, setCardDetails] = useState<CardArchetype | null>(null);

  const performLookup = useCallback((month: number, day: number) => {
    const monthStr = String(month).padStart(2, '0');
    const dayStr = String(day).padStart(2, '0');
    const key = `${monthStr}-${dayStr}`;
    const cardNameData = (cardData.planetary_ruling_card_by_date as any)[key];

    const cardName = Array.isArray(cardNameData) ? cardNameData.join(' or ') : cardNameData;

    if (cardName) {
      const card = mapNameToCard(cardName);
      setResultCard(card);

      if (card) {
        const cardKey = mapCardToKey(card);
        const details = archetypeSystemData.cards[cardKey];
        if (details) {
          setCardDetails(details);
        } else {
          setCardDetails(null); // Reset if not found
        }
      }
      setViewState(ViewState.RESULT);
    } else {
        console.error(`Card not found for date: ${key}`);
    }
  }, []);

  useEffect(() => {
    if (birthDate) {
        performLookup(birthDate.month, birthDate.day);
    }
  }, [birthDate, performLookup]);


  const handleShowMeaning = useCallback(() => {
    if (!resultCard) return;
    setViewState(ViewState.MEANING);
  }, [resultCard]);

  const handleBackToCard = useCallback(() => {
    setViewState(ViewState.RESULT);
  }, []);

  const handleNext = () => {
    if(resultCard) {
        onComplete(resultCard);
    }
  }

  const renderContent = () => {
    switch (viewState) {
      case ViewState.FORM:
        return (
          <BirthCardForm 
            onSubmit={performLookup}
            isProcessing={false} // Lookup is synchronous
            title="Your Public Persona"
            subtitle="This is your user interface. The mask you show the world. It can be for any day, but you probably want to start with your birthday."
            submitText="Reveal Persona"
            loadingText="Scanning facades..."
          />
        );
      case ViewState.RESULT:
        if (!resultCard) return null;
        return (
          <CardResult 
            card={resultCard} 
            onShowMeaning={handleShowMeaning} 
            onReset={onStartOver}
            onNext={handleNext}
            nextText="Next: Audit Your Karma"
            title="Public Persona Identified"
            subtitle="This is how you deal with... people. It’s the tool you use to deploy the energy of your core Birth Card. Or hide it. Your call."
          />
        );
      case ViewState.MEANING:
        if (!resultCard) return null;
        if (!cardDetails) {
            return (
              <div className="w-full max-w-md mx-auto animate-gentle-slide-fade-in">
                <div className="bg-gray-800 bg-opacity-50 backdrop-blur-sm p-6 sm:p-8 rounded-2xl shadow-2xl border border-gray-700 text-center">
                  <h2 className="text-2xl font-bold text-gray-300 mb-4">Data Anomaly</h2>
                  <p className="text-gray-400 mb-6">{`Apparently, archetype data for the "${resultCard.name}" is classified. Or we just don't have it. Probably the latter.`}</p>
                  <button onClick={handleBackToCard} className="w-full bg-gray-700 text-gray-300 font-bold py-3 px-4 rounded-lg hover:bg-gray-600">
                    &larr; Return to Sanity
                  </button>
                </div>
              </div>
            );
        }
        return (
          <ArchetypeDetailView 
            card={resultCard} 
            cardDetails={cardDetails} 
            onBack={handleBackToCard} 
            context="PRC"
            birthCard={birthCard}
          />
        );
      default:
        return (
           <BirthCardForm 
            onSubmit={performLookup}
            isProcessing={false}
            title="Your Public Persona"
            subtitle="This is your user interface. The mask you show the world. It can be for any day, but you probably want to start with your birthday."
            submitText="Reveal Persona"
            loadingText="Scanning facades..."
          />
        );
    }
  };

  return (
    <div key={viewState} className="relative w-full">
      {renderContent()}
    </div>
  );
};

export default PrcLookup;