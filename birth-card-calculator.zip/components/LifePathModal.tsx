import React, { useEffect, useState } from 'react';
import { Card, StageInfo } from '../types';
import CardDisplay from './CardDisplay';
import { GoogleGenAI } from '@google/genai';
import MarkdownRenderer from './MarkdownRenderer';
import { archetypeSystemData } from '../services/archetypeData';
import { mapCardToKey } from '../services/cardService';

interface LifePathModalProps {
  isOpen: boolean;
  onClose: () => void;
  birthCard: Card;
  personaCard: Card | null;
  card: Card;
  stageInfo: StageInfo;
}

const LifePathModal: React.FC<LifePathModalProps> = ({ isOpen, onClose, birthCard, personaCard, card, stageInfo }) => {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    // Reset state when modal opens for a new card
    if (isOpen) {
        setAnalysis(null);
        setError(null);
        setIsLoading(false);
    }
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  const getAnalysis = async () => {
      setIsLoading(true);
      setError(null);
      setAnalysis(null);

      const cardKey = mapCardToKey(card);
      const cardDetails = archetypeSystemData.cards[cardKey];
      if (!cardDetails) {
          setError("Could not find archetype details for this card.");
          setIsLoading(false);
          return;
      }

      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          const prompt = `
              You are an expert card reader with a direct, no-nonsense style. Your analysis is plain-spoken, serious, and insightful, focusing on the structure of a person's life path.

              **User's Profile:**
              - **Birth Card (Core Identity):** ${birthCard.name}
              - **Persona Card (Public Mask):** ${personaCard ? personaCard.name : 'Unknown'}
              - **Life Path Card to Analyze:** ${card.name} (${cardDetails.archetype})
              - **Life Path Position:** ${stageInfo.name} (${stageInfo.description.short})

              **Position Meaning:**
              ${stageInfo.description.full}

              **Task:**
              Provide a direct, serious analysis of what it means for someone with a **${birthCard.name}** core identity, who presents to the world as a **${personaCard ? personaCard.name : 'generic persona'}**, to have the **${card.name}** as their **${stageInfo.name}** card.

              Interweave the positive and negative potentials. Synthesize all three cards and the position's meaning. Explain how the energy of the ${card.name} specifically influences the area of life defined by the ${stageInfo.name} position. How does this interaction play out for a person with this specific combination of core identity and public persona? Be direct, plain-spoken, and avoid mystical fluff. Format using simple markdown.
          `;
          
          const response = await ai.models.generateContent({
              model: 'gemini-2.5-flash',
              contents: prompt,
          });
          setAnalysis(response.text);

      } catch (err) {
          console.error("Gemini API call failed:", err);
          setError("An error occurred during the analysis. Please try again later.");
      } finally {
          setIsLoading(false);
      }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div 
        className="fixed inset-0 bg-black bg-opacity-70 z-50 flex items-center justify-center p-4 animate-fade-in"
        onClick={onClose}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
    >
      <div 
        className="bg-gray-800 border border-gray-700 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 relative animate-slide-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
            onClick={onClose} 
            className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors z-10"
            aria-label="Close modal"
        >
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="flex flex-col md:flex-row gap-8">
            <div className="flex-shrink-0 mx-auto md:mx-0 flex flex-col items-center">
                 <CardDisplay card={card} />
            </div>
            <div className="flex-1 md:w-2/3">
                 <h2 id="modal-title" className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-2">
                    {stageInfo.name}
                </h2>
                <p className="text-lg text-gray-400 italic mb-6">{stageInfo.description.short}</p>

                <div className="space-y-6">
                    <div>
                        <h3 className="text-xl font-semibold text-purple-300 mb-2">Stage Description</h3>
                        <p className="text-gray-300 leading-relaxed">{stageInfo.description.full}</p>
                    </div>
                     <div>
                        <h3 className="text-xl font-semibold text-purple-300 mb-2">Relational Meaning</h3>
                        <p className="text-gray-400 italic mb-2">"{stageInfo.relational.short}"</p>
                        <p className="text-gray-300 leading-relaxed">{stageInfo.relational.full}</p>
                    </div>
                </div>
            </div>
        </div>

        {/* Gemini Section */}
        <div className="mt-8 pt-6 border-t border-gray-700">
            <h3 className="text-2xl font-bold text-center mb-4 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">Deeper Analysis</h3>
            
            {!analysis && !isLoading && (
                <div className="text-center animate-fade-in">
                    <p className="text-gray-400 mb-4 max-w-2xl mx-auto">Request a direct, tactical analysis from Gemini. It will synthesize your core identity, the card, and this life position into a single, no-BS interpretation.</p>
                    <button 
                        onClick={getAnalysis} 
                        disabled={isLoading} 
                        className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:from-purple-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 transition-all duration-300 transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Go Deeper
                    </button>
                </div>
            )}

            {isLoading && (
                <div className="flex justify-center items-center p-8 animate-fade-in">
                    <svg className="animate-spin h-8 w-8 text-purple-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <p className="ml-4 text-gray-400 text-lg">Processing...</p>
                </div>
            )}

            {error && <p className="text-red-400 text-center p-4 bg-red-900/20 rounded-lg">{error}</p>}
            
            {analysis && (
                <div className="mt-4 bg-gray-900/50 p-6 rounded-lg border border-gray-700 animate-fade-in">
                    <MarkdownRenderer content={analysis} />
                </div>
            )}
        </div>

      </div>
    </div>
  );
};

export default LifePathModal;