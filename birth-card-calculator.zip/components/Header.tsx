import React from 'react';

export type View = 'BIRTH_CARD' | 'PRC_LOOKUP' | 'LIFE_PATH' | 'KARMA_CARDS' | 'DAILY_READING' | 'CARD_LIBRARY' | 'ARCHETYPES';

interface HeaderProps {
  activeView: View;
  setActiveView: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ activeView, setActiveView }) => {
  const navItemClass = (view: View) => 
    `px-3 py-2 rounded-md text-xs sm:text-sm font-medium transition-colors duration-200 cursor-pointer whitespace-nowrap ${
      activeView === view
        ? 'bg-purple-600 text-white shadow-lg'
        : 'text-gray-300 hover:bg-gray-700 hover:text-white'
    }`;

  return (
    <header className="absolute top-0 left-0 right-0 p-4 z-10">
      <nav className="max-w-xl sm:max-w-3xl mx-auto bg-gray-800 bg-opacity-70 backdrop-blur-sm p-2 rounded-xl shadow-lg border border-gray-700 flex flex-wrap justify-center gap-1 sm:gap-2">
        <button onClick={() => setActiveView('BIRTH_CARD')} className={navItemClass('BIRTH_CARD')} aria-pressed={activeView === 'BIRTH_CARD'}>
          Birth Card
        </button>
        <button onClick={() => setActiveView('PRC_LOOKUP')} className={navItemClass('PRC_LOOKUP')} aria-pressed={activeView === 'PRC_LOOKUP'}>
          Persona Card
        </button>
         <button onClick={() => setActiveView('DAILY_READING')} className={navItemClass('DAILY_READING')} aria-pressed={activeView === 'DAILY_READING'}>
          Daily Reading
        </button>
        <button onClick={() => setActiveView('KARMA_CARDS')} className={navItemClass('KARMA_CARDS')} aria-pressed={activeView === 'KARMA_CARDS'}>
          Karma Cards
        </button>
         <button onClick={() => setActiveView('LIFE_PATH')} className={navItemClass('LIFE_PATH')} aria-pressed={activeView === 'LIFE_PATH'}>
          Life Path
        </button>
        <button onClick={() => setActiveView('CARD_LIBRARY')} className={navItemClass('CARD_LIBRARY')} aria-pressed={activeView === 'CARD_LIBRARY'}>
          Card Library
        </button>
        <button onClick={() => setActiveView('ARCHETYPES')} className={navItemClass('ARCHETYPES')} aria-pressed={activeView === 'ARCHETYPES'}>
          Archetypes
        </button>
      </nav>
    </header>
  );
};

export default Header;