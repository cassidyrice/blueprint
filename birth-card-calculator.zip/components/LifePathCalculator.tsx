
import React, { useState, useCallback, useEffect } from 'react';
import BirthCardForm from './BirthCardForm';
import LifePathResult from './LifePathResult';
import { Card } from '../types';
import { calculateSolarValue, mapValueToCard, normalizeCardNameForKey } from '../services/cardService';
import { lifePathData } from '../services/lifePathData';

enum ViewState {
  FORM,
  RESULT,
}

interface LifePathCalculatorProps {
    birthDate: { month: number; day: number } | null;
    birthCard: Card | null;
    personaCard: Card | null;
    onStartOver: () => void;
}

const LifePathCalculator: React.FC<LifePathCalculatorProps> = ({ birthDate, birthCard, personaCard, onStartOver }) => {
  const [viewState, setViewState] = useState<ViewState>(birthCard ? ViewState.RESULT : ViewState.FORM);
  const [displayBirthCard, setDisplayBirthCard] = useState<Card | null>(birthCard);
  const [path, setPath] = useState<typeof lifePathData[string] | null>(null);

  const performLookup = useCallback((card: Card) => {
    const key = normalizeCardNameForKey(card.name);
    const lifePath = lifePathData[key];
    if (lifePath) {
      setDisplayBirthCard(card);
      setPath(lifePath);
      setViewState(ViewState.RESULT);
    } else {
      setDisplayBirthCard(card);
      setPath(null); // No path found
      setViewState(ViewState.RESULT);
    }
  }, []);

  const handleFormSubmit = useCallback((month: number, day: number) => {
    const solarValue = calculateSolarValue(month, day);
    const card = mapValueToCard(solarValue);
    performLookup(card);
  }, [performLookup]);
  
  useEffect(() => {
    if (birthCard) {
        performLookup(birthCard);
    } else {
        setViewState(ViewState.FORM);
    }
  }, [birthCard, performLookup]);


  const renderContent = () => {
    switch (viewState) {
      case ViewState.FORM:
        return (
          <BirthCardForm 
            onSubmit={handleFormSubmit}
            isProcessing={false}
            title="Your Life Map"
            subtitle="This is the architectural blueprint of your life's major energetic currents. Enter your birth date to see the map."
            submitText="Chart My Path"
            loadingText="Plotting coordinates..."
          />
        );
      case ViewState.RESULT:
        if (!displayBirthCard) return null;
        return <LifePathResult birthCard={displayBirthCard} personaCard={personaCard} path={path} onReset={onStartOver} />;
      default:
        return (
          <BirthCardForm 
            onSubmit={handleFormSubmit}
            isProcessing={false}
            title="Your Life Map"
            subtitle="This is the architectural blueprint of your life's major energetic currents. Enter your birth date to see the map."
            submitText="Chart My Path"
            loadingText="Plotting coordinates..."
          />
        );
    }
  };

  return (
    <div key={viewState} className="relative w-full">
      {renderContent()}
    </div>
  );
};

export default LifePathCalculator;
