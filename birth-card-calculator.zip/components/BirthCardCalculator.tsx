import React, { useState, useCallback } from 'react';
import BirthCardForm from './BirthCardForm';
import CardResult from './CardResult';
import ArchetypeDetailView from './ArchetypeDetailView';
import { Card, CardArchetype } from '../types';
import { calculateSolarValue, mapValueToCard, mapCardToKey } from '../services/cardService';
import { archetypeSystemData } from '../services/archetypeData';
import CalculationDisplay from './CalculationDisplay';

enum ViewState {
  FORM,
  CALCULATING,
  RESULT,
  MEANING,
}

interface BirthCardCalculatorProps {
    onComplete: (date: { month: number; day: number }, card: Card) => void;
}

const BirthCardCalculator: React.FC<BirthCardCalculatorProps> = ({ onComplete }) => {
  const [viewState, setViewState] = useState<ViewState>(ViewState.FORM);
  const [birthDate, setBirthDate] = useState<{ month: number; day: number } | null>(null);
  const [birthCard, setBirthCard] = useState<Card | null>(null);
  const [cardDetails, setCardDetails] = useState<CardArchetype | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFormSubmit = useCallback((month: number, day: number) => {
    setIsProcessing(true);
    setBirthDate({ month, day });
    setViewState(ViewState.CALCULATING);
  }, []);
  
  const handleCalculationComplete = useCallback(() => {
    if (birthDate) {
        const solarValue = calculateSolarValue(birthDate.month, birthDate.day);
        const card = mapValueToCard(solarValue);
        setBirthCard(card);

        const cardKey = mapCardToKey(card);
        const details = archetypeSystemData.cards[cardKey];
        if (details) {
            setCardDetails(details);
        }
        setViewState(ViewState.RESULT);
        setIsProcessing(false);
    }
  }, [birthDate]);

  const handleShowMeaning = useCallback(() => {
    if (!birthCard) return;
    setViewState(ViewState.MEANING);
  }, [birthCard]);

  const handleReset = useCallback(() => {
    setBirthDate(null);
    setBirthCard(null);
    setCardDetails(null);
    setViewState(ViewState.FORM);
  }, []);

  const handleBackToCard = useCallback(() => {
    setViewState(ViewState.RESULT);
  }, []);

  const handleNext = () => {
    if (birthDate && birthCard) {
      onComplete(birthDate, birthCard);
    }
  };

  const renderContent = () => {
    switch (viewState) {
      case ViewState.FORM:
        return (
          <BirthCardForm 
            onSubmit={handleFormSubmit}
            isProcessing={isProcessing}
            title="Your Core Code"
            subtitle="Enter your date of manufacture. We'll tell you what you are."
            submitText="Analyze"
            loadingText="Analyzing..."
          />
        );
      case ViewState.CALCULATING:
        if (!birthDate) return null;
        return (
            <CalculationDisplay
                month={birthDate.month}
                day={birthDate.day}
                onComplete={handleCalculationComplete}
            />
        );
      case ViewState.RESULT:
        if (!birthCard) return null;
        return (
          <CardResult 
            card={birthCard} 
            onShowMeaning={handleShowMeaning} 
            onReset={handleReset}
            onNext={handleNext}
            nextText="Next: Discover Your Persona"
            title="Core Identity Identified"
            subtitle="This is your factory setting. Your core operating system. Now find out about the public-facing software you run on top of it."
          />
        );
      case ViewState.MEANING:
        if (!birthCard || !cardDetails) return null;
        return <ArchetypeDetailView card={birthCard} cardDetails={cardDetails} onBack={handleBackToCard} context="Birth Card" />;
      default:
        return (
          <BirthCardForm 
            onSubmit={handleFormSubmit}
            isProcessing={isProcessing}
            title="Your Core Code"
            subtitle="Enter your date of manufacture. We'll tell you what you are."
            submitText="Analyze"
            loadingText="Analyzing..."
          />
        );
    }
  };

  return (
    <div key={viewState} className="relative w-full">
      {renderContent()}
    </div>
  );
};

export default BirthCardCalculator;