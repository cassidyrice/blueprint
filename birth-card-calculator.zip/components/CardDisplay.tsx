import React from 'react';
import { Card } from '../types';
import { getSuitColor } from '../utils/cardUtils';

interface CardDisplayProps {
  card: Card | null;
  size?: 'small' | 'medium';
  placeholderText?: string;
}

const CardDisplay: React.FC<CardDisplayProps> = ({ card, size = 'medium', placeholderText = 'None' }) => {
  const sizeClasses = {
    small: 'w-32 h-[7rem] p-2 text-base',
    medium: 'w-60 sm:w-72 aspect-[2.5/3.5] p-4 text-2xl',
  };
  const currentSizeClass = sizeClasses[size] || sizeClasses.medium;

  if (!card) {
    return (
      <div className={`${currentSizeClass} bg-gray-800 rounded-xl shadow-lg flex justify-center items-center border-2 border-dashed border-gray-600 text-gray-400 animate-card-flip-in`}>
          <span className="font-bold">{placeholderText}</span>
      </div>
    );
  }

  const colorClass = getSuitColor(card.suit);
  const nameParts = card.name.split(' of ');

  return (
    <div className={`${currentSizeClass} bg-gray-800 rounded-xl shadow-lg flex flex-col justify-center items-center border border-gray-700 text-center animate-card-flip-in`}>
      <div className={`font-serif font-bold ${colorClass}`}>
        {nameParts.length > 1 ? (
          <div className="flex flex-col leading-tight">
            <span>{nameParts[0]}</span>
            <span className="text-sm opacity-80 font-normal">of</span>
            <span>{nameParts[1]}</span>
          </div>
        ) : (
          <span>{card.name}</span>
        )}
      </div>
    </div>
  );
};

export default CardDisplay;
