import React, { useState, useCallback, useEffect } from 'react';
import BirthCardForm from './BirthCardForm';
import KarmaCardResult from './KarmaCardResult';
import { Card } from '../types';
import { calculateSolarValue, mapValueToCard, mapNameToCard } from '../services/cardService';
import { karmaCardData } from '../services/karmaData';

enum ViewState {
  FORM,
  RESULT,
}

interface KarmaCardCalculatorProps {
    birthDate: { month: number; day: number } | null;
    birthCard: Card | null;
    personaCard: Card | null;
    onComplete: () => void;
    onStartOver: () => void;
}

const KarmaCardCalculator: React.FC<KarmaCardCalculatorProps> = ({ birthDate, birthCard, personaCard, onComplete, onStartOver }) => {
  const [viewState, setViewState] = useState<ViewState>(birthCard ? ViewState.RESULT : ViewState.FORM);
  const [displayBirthCard, setDisplayBirthCard] = useState<Card | null>(birthCard);
  const [negativeKarmaCard, setNegativeKarmaCard] = useState<Card | null>(null);
  const [positiveKarmaCard, setPositiveKarmaCard] = useState<Card | null>(null);

  const performLookup = useCallback((bCard: Card) => {
    if (bCard.name === 'Joker') {
      setDisplayBirthCard(bCard);
      setNegativeKarmaCard(null);
      setPositiveKarmaCard(null);
      setViewState(ViewState.RESULT);
      return;
    }
    
    const karmaCards = karmaCardData[bCard.name];

    if (karmaCards) {
      setDisplayBirthCard(bCard);
      setNegativeKarmaCard(mapNameToCard(karmaCards.negative));
      setPositiveKarmaCard(mapNameToCard(karmaCards.positive));
      setViewState(ViewState.RESULT);
    } else {
      // Handle case where birth card is not in karma data, though it should be.
      setDisplayBirthCard(bCard);
      setNegativeKarmaCard(null);
      setPositiveKarmaCard(null);
      setViewState(ViewState.RESULT);
    }
  }, []);

  const handleFormSubmit = useCallback((month: number, day: number) => {
    const solarValue = calculateSolarValue(month, day);
    const bCard = mapValueToCard(solarValue);
    performLookup(bCard);
  }, [performLookup]);

  useEffect(() => {
    if (birthCard) {
        performLookup(birthCard);
    } else {
        setViewState(ViewState.FORM);
    }
  }, [birthCard, performLookup]);
  

  const renderContent = () => {
    switch (viewState) {
      case ViewState.FORM:
        return (
          <BirthCardForm 
            onSubmit={handleFormSubmit}
            isProcessing={false}
            title="Karmic Balance Sheet"
            subtitle="Every action has a reaction. This is the metaphysical ledger from your past. Enter your birth date to see your assets and liabilities."
            submitText="Audit My Karma"
            loadingText="Reconciling accounts..."
          />
        );
      case ViewState.RESULT:
        if (!displayBirthCard) return null;
        return (
          <KarmaCardResult 
            birthCard={displayBirthCard}
            personaCard={personaCard}
            negativeKarmaCard={negativeKarmaCard}
            positiveKarmaCard={positiveKarmaCard}
            onReset={onStartOver}
            onNext={onComplete}
          />
        );
      default:
        return (
          <BirthCardForm 
            onSubmit={handleFormSubmit}
            isProcessing={false}
            title="Karmic Balance Sheet"
            subtitle="Every action has a reaction. This is the metaphysical ledger from your past. Enter your birth date to see your assets and liabilities."
            submitText="Audit My Karma"
            loadingText="Reconciling accounts..."
          />
        );
    }
  };

  return (
    <div key={viewState} className="relative w-full">
      {renderContent()}
    </div>
  );
};

export default KarmaCardCalculator;