import React, { useState, useEffect } from 'react';

interface CalculationDisplayProps {
  month: number;
  day: number;
  onComplete: () => void;
}

const CalculationDisplay: React.FC<CalculationDisplayProps> = ({ month, day, onComplete }) => {
  const [step, setStep] = useState(0);

  const solarValue = 55 - (2 * month + day);

  useEffect(() => {
    const timers = [
      setTimeout(() => setStep(1), 500),
      setTimeout(() => setStep(2), 1500),
      setTimeout(() => setStep(3), 2500),
      setTimeout(() => onComplete(), 3500),
    ];
    return () => timers.forEach(clearTimeout);
  }, [onComplete]);

  const getStepClass = (stepNum: number) => {
    return step >= stepNum ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4';
  };

  return (
    <div className="w-full max-w-md mx-auto text-center font-mono p-8 bg-gray-800 rounded-xl shadow-lg border border-gray-700 animate-fade-in">
      <p className={`text-gray-400 mb-4 transition-all duration-500 ${getStepClass(0)}`}>
        Calculating Solar Value...
      </p>
      <div className="text-2xl sm:text-3xl font-bold text-white space-y-3">
        <p className={`transition-all duration-500 ${getStepClass(1)}`}>
          55 - (2 * {month} + {day})
        </p>
        <p className={`transition-all duration-500 ${getStepClass(2)}`}>
          = 55 - ({2 * month + day})
        </p>
        <p className={`text-purple-400 transition-all duration-500 ${getStepClass(3)}`}>
          = {solarValue}
        </p>
      </div>
    </div>
  );
};

export default CalculationDisplay;