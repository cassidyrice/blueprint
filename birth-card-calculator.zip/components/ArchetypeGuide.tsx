import React from 'react';
import { archetypeSystemData } from '../services/archetypeData';
import { getSuitColor } from '../utils/cardUtils';

const ArchetypeGuide: React.FC = () => {
    const { numberMeanings, suitInfluences } = archetypeSystemData;

  return (
    <div className="w-full max-w-4xl mx-auto animate-fade-in">
        <div className="bg-gray-800 bg-opacity-50 backdrop-blur-sm p-6 sm:p-8 rounded-2xl shadow-2xl border border-gray-700">
            <div className="text-center mb-12">
                <h2 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">
                    Archetype Systematics
                </h2>
                <p className="text-gray-400 max-w-2xl mx-auto mt-2">
                    The foundational components of the system. Numbers define function (The 'What'). Suits define the operational domain (The 'Where'). Their combination creates the archetype.
                </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Number Meanings */}
                <div className="animate-gentle-slide-fade-in opacity-0" style={{ animationDelay: '200ms' }}>
                    <h3 className="text-2xl font-bold text-purple-300 mb-4">Number Meanings (The WHAT)</h3>
                    <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700">
                        <div className="overflow-x-auto">
                            <table className="w-full text-left min-w-[500px]">
                                <thead>
                                    <tr>
                                        <th className="p-2 sm:p-3 text-sm font-semibold text-gray-400 uppercase tracking-wider">#</th>
                                        <th className="p-2 sm:p-3 text-sm font-semibold text-gray-400 uppercase tracking-wider">Name</th>
                                        <th className="p-2 sm:p-3 text-sm font-semibold text-gray-400 uppercase tracking-wider">Core Trait</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-700">
                                    {numberMeanings.map(n => (
                                        <tr key={n.number} className="hover:bg-gray-800/50 transition-colors">
                                            <td className="p-2 sm:p-3 font-bold text-lg text-gray-200">{n.number}</td>
                                            <td className="p-2 sm:p-3 text-gray-300">{n.name}</td>
                                            <td className="p-2 sm:p-3 text-gray-400 text-sm">{n.core_trait}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                {/* Suit Influences */}
                <div className="animate-gentle-slide-fade-in opacity-0" style={{ animationDelay: '400ms' }}>
                    <h3 className="text-2xl font-bold text-purple-300 mb-4">Suit Influences (The WHERE)</h3>
                     <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700">
                        <div className="overflow-x-auto">
                            <table className="w-full text-left min-w-[500px]">
                                <thead>
                                    <tr>
                                        <th className="p-2 sm:p-3 text-sm font-semibold text-gray-400 uppercase tracking-wider">Suit</th>
                                        <th className="p-2 sm:p-3 text-sm font-semibold text-gray-400 uppercase tracking-wider">Focus</th>
                                        <th className="p-2 sm:p-3 text-sm font-semibold text-gray-400 uppercase tracking-wider">Energy</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-700">
                                    {suitInfluences.map(s => (
                                        <tr key={s.suit} className="hover:bg-gray-800/50 transition-colors">
                                            <td className="p-2 sm:p-3">
                                                <div className="flex items-center gap-3">
                                                    <span className={`font-bold text-lg ${getSuitColor(s.suit)}`}>{s.suit}</span>
                                                    <span className="font-bold text-lg text-gray-200">({s.realm})</span>
                                                </div>
                                            </td>
                                            <td className="p-2 sm:p-3 text-gray-400 text-sm">{s.focus}</td>
                                            <td className="p-2 sm:p-3 text-gray-400 text-sm">{s.energy}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default ArchetypeGuide;
