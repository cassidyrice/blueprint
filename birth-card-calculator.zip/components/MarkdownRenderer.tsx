import React from 'react';

interface MarkdownRendererProps {
  content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const renderContent = () => {
    // This is a basic parser. For more complex markdown, a library like 'marked' or 'react-markdown' would be better.
    // However, for Gemini's typical output of paragraphs, bold text, and occasional headers, this is sufficient and lightweight.
    
    // Split by newlines to handle paragraphs and headers
    const blocks = content.split('\n').filter(line => line.trim() !== '');

    return blocks.map((block, index) => {
      // Create a mutable line for processing
      let line = block;

      // Handle Headers (e.g., ## The High Side)
      if (line.startsWith('## ')) {
        const headerText = line.substring(3).replace(/\*\*(.*?)\*\*/g, '$1'); // clean extra bolding
        return <h2 key={index} className="text-2xl font-bold text-purple-300 mt-6 mb-3" dangerouslySetInnerHTML={{ __html: headerText }} />;
      }
      
       if (line.startsWith('**') && line.endsWith('**')) {
        return <h2 key={index} className="text-2xl font-bold text-purple-300 mt-6 mb-3" dangerouslySetInnerHTML={{ __html: line.substring(2, line.length - 2) }} />;
      }


      // Handle Bold: **text**
      line = line.replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-purple-200">$1</strong>');
      
      // Handle Italic: *text* (though less common in this context)
      line = line.replace(/\*(.*?)\*/g, '<em>$1</em>');

      return <p key={index} className="mb-4" dangerouslySetInnerHTML={{ __html: line }} />;
    });
  };

  return <div className="text-gray-300 leading-relaxed">{renderContent()}</div>;
};

export default MarkdownRenderer;
