import { cardData } from './cardData';

const processedKarmaData: { [birthCard: string]: { negative: string; positive: string; } } = {};

for (const birthCard in cardData.karma_cards_by_birth_card) {
    const karmaInfo = (cardData.karma_cards_by_birth_card as any)[birthCard];
    
    // Karma data can contain multiple cards, we'll join them. mapNameToCard will pick the first.
    const negativeStr = karmaInfo.negative.length > 0 ? karmaInfo.negative.join(' or ') : 'None';
    const positiveStr = karmaInfo.positive.length > 0 ? karmaInfo.positive.join(' or ') : 'None';

    processedKarmaData[birthCard] = {
        negative: negativeStr,
        positive: positiveStr
    };
}

export const karmaCardData = processedKarmaData;
