import { StageInfo } from '@/types';

export const lifePathStageInfo: { [key: string]: StageInfo } = {
    'Birth Card': {
        name: 'Primary Energy',
        description: {
            short: 'You shine this light',
            full: 'The Birth Card is your sun-shining energy. It\'s your primary gift to give. The other 12 cards in your Life Path act as the supporting cast in your life story.'
        },
        relational: {
            short: 'A mirror with which to see yourself',
            full: 'People born to play this card are a mirror to you. You may feel like "two peas in a pod." Or this person may reveal annoying, unacknowledged habits that you have.'
        }
    },
    'Mercury': {
        name: 'Mercury Influence',
        description: {
            short: 'You think like this',
            full: 'This card reveals the contents of your mind, positively and negatively. It\'s what you think about, how you think, and what you talk about. You may even think this is who you are.'
        },
        relational: {
            short: 'A close confidant',
            full: 'You have a strong mental connection with people born to play this card. You think alike. It\'s easy to talk to this person, and you have much to talk about.'
        }
    },
    'Venus': {
        name: 'Venus Influence',
        description: {
            short: 'You love like this',
            full: 'This card reveals your feminine side, what you love in life, and what you consider beautiful. You experience this energy, both positively and negatively, in your romantic relationships.'
        },
        relational: {
            short: 'A lover and/or a friend',
            full: 'You may feel inexplicably drawn to people who have this card to play, like the arrow of Cupid has pierced your heart.'
        }
    },
    'Mars': {
        name: 'Mars Influence',
        description: {
            short: 'You act like this',
            full: 'This card reveals your masculine, aggressive side both positively and negatively. It represents the goals you have in life and how you work toward achieving those goals.'
        },
        relational: {
            short: 'Sparks fly and/or tempers flare',
            full: 'People born to play this card stimulate you and excite you. However, they may also compete with you, challenge you, and confront you.'
        }
    },
    'Jupiter': {
        name: 'Jupiter Influence',
        description: {
            short: 'You grow from this',
            full: 'The energy of this card expands your horizons, opening you to a more, more abundant experience. Too much positive expansion, however, and the negative aspects of this energy can also inflate your ego.'
        },
        relational: {
            short: 'An expansive influence',
            full: 'You benefit from people born to play this card. These people expand your horizons, opening you to receive more of life\'s abundance.'
        }
    },
    'Saturn': {
        name: 'Saturn Influence',
        description: {
            short: 'You learn from this',
            full: 'This card reveals the negative patterns that repeatedly limit you in life... until you learn the lesson. As you do learn and grow, the positive side of this energy provides you balance and stability in your health and wellbeing.'
        },
        relational: {
            short: 'A teacher or a taskmaster',
            full: 'People born to play this card may guide you in life. They remind you of your lessons to learn. As such, there could be friction and resistance between you both.'
        }
    },
    'Uranus': {
        name: 'Uranus Influence',
        description: {
            short: 'The pivotal shift of your life',
            full: 'This card reveals what keeps you grounded, sane, and centered in yourself. Negatively, this energy can clip your wings, grounding you unexpectedly. Positively, this energy connects you to the upper reaches of your potential.'
        },
        relational: {
            short: 'A friendly but variable presence',
            full: 'You may be friends with and receive pivotal benefit from someone with this card to play. But their connection to you may be uneven and unpredictable. And they may be full of surprises.'
        }
    },
    'Neptune': {
        name: 'Neptune Influence',
        description: {
            short: 'A fantastic power at your command',
            full: 'This card reveals the subject of your recurring daydreams and fantasies. You can get lost in your illusions of this energy, or you can work to build a solid foundation underneath your dreamy castles in the sky.'
        },
        relational: {
            short: 'An object of your desire and/or delusion',
            full: 'This person may be dreamy to you. You may see this person through rose-colored glasses, as if they could do no wrong... until that illusion is shattered, and you must re-establish your connection on solid ground.'
        }
    },
    'Pluto': {
        name: 'Pluto Influence',
        description: {
            short: 'The shadow that you must face',
            full: 'This card represents your unconscious, hidden side. You may irrationally fear the positive attributes of this card, meanwhile unconsciously acting out the negative attributes. In order to evolve, you must learn to integrate and express the positive attributes of this energy.'
        },
        relational: {
            short: 'A shadowy, uneasy presence',
            full: 'People with this card to play reveal your shadow side, the very thing you may try to keep hidden. Until you are completely comfortable facing your own shadow, you may find these people awkward, invasive, and repugnant.'
        }
    },
    'Result': {
        name: 'The Princess',
        description: {
            short: 'As you grow, you receive this',
            full: 'This card reveals the reward you desire in life. You receive the positive aspects of this card as you play your other cards right. But still, you may not feel worthy to receive it. You are learning to receive the positive aspects of this energy freely, as a gift of grace.'
        },
        relational: {
            short: 'A possible gift in your life',
            full: 'People with this card to play show up for you as a gift, if and when you are ready to welcome them fully into your life.'
        }
    },
    'Cosmic Lesson': {
        name: 'The Prince',
        description: {
            short: 'As you grow, you do this',
            full: 'This card reveals your responsibility in life. Instead of avoiding this responsibility and thereby acting out this energy negatively, you must take personal responsibility to generate the positive expression of this energy.'
        },
        relational: {
            short: 'Someone who tests your patience',
            full: 'People with this card to play may irk you or frustrate you. Energetically, they challenge you to grow and take personal responsibility for your life.'
        }
    },
    'Cosmic Moon': {
        name: 'The Queen',
        description: {
            short: 'As you grow, you become this',
            full: 'This card represents the energy you are learning to embody and exemplify as your own. As you welcome the positive aspects of this card into your self-expression, its energy nurtures you to grow into the final stage of your soul\'s evolution.'
        },
        relational: {
            short: 'An advocate of your self-expression',
            full: 'People born to play this card are supportive to you. You likely share a strong sense of intimacy and connection with them. They help you embody the fullness of who you are in life. As such, they may take a supportive role in your life.'
        }
    },
    'Transformed Self': {
        name: 'The King',
        description: {
            short: 'As you grow, you command this',
            full: 'This card reveals the energy with which you can command your reality. But this energy may feel distant and impossible to attain, like a foggy, mysterious cloud on the horizon of your becoming. You might even lose hope of attaining the positive aspects of this energy and shrink back in self-defeat. Or you can proactively seek to grow into the full expression of this energy.'
        },
        relational: {
            short: 'An example for your own greatness',
            full: 'People with this card to play will, at their best, model for you the path of your own greatness. You may, however, feel like they are distant, mysterious, or aloof.'
        }
    }
};
