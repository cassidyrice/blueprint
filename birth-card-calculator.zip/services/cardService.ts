
import { Rank, Suit, Card } from '@/types';

// This array maps solar value (index 0-52) to a card.
const solarValueMap: { suit: Suit; rank: Rank; name: string }[] = [
  // Value 0
  { suit: Suit.Joker, rank: Rank.Joker, name: 'Joker' },
  // Hearts (1-13)
  { suit: Suit.Hearts, rank: Rank.Ace, name: 'Ace of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Two, name: 'Two of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Three, name: 'Three of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Four, name: 'Four of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Five, name: 'Five of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Six, name: 'Six of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Seven, name: 'Seven of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Eight, name: 'Eight of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Nine, name: 'Nine of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Ten, name: 'Ten of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Jack, name: 'Jack of Hearts' },
  { suit: Suit.Hearts, rank: Rank.Queen, name: 'Queen of Hearts' },
  { suit: Suit.Hearts, rank: Rank.King, name: 'King of Hearts' },
  // Clubs (14-26)
  { suit: Suit.Clubs, rank: Rank.Ace, name: 'Ace of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Two, name: 'Two of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Three, name: 'Three of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Four, name: 'Four of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Five, name: 'Five of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Six, name: 'Six of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Seven, name: 'Seven of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Eight, name: 'Eight of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Nine, name: 'Nine of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Ten, name: 'Ten of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Jack, name: 'Jack of Clubs' },
  { suit: Suit.Clubs, rank: Rank.Queen, name: 'Queen of Clubs' },
  { suit: Suit.Clubs, rank: Rank.King, name: 'King of Clubs' },
  // Diamonds (27-39)
  { suit: Suit.Diamonds, rank: Rank.Ace, name: 'Ace of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Two, name: 'Two of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Three, name: 'Three of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Four, name: 'Four of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Five, name: 'Five of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Six, name: 'Six of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Seven, name: 'Seven of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Eight, name: 'Eight of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Nine, name: 'Nine of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Ten, name: 'Ten of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Jack, name: 'Jack of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.Queen, name: 'Queen of Diamonds' },
  { suit: Suit.Diamonds, rank: Rank.King, name: 'King of Diamonds' },
  // Spades (40-52)
  { suit: Suit.Spades, rank: Rank.Ace, name: 'Ace of Spades' },
  { suit: Suit.Spades, rank: Rank.Two, name: 'Two of Spades' },
  { suit: Suit.Spades, rank: Rank.Three, name: 'Three of Spades' },
  { suit: Suit.Spades, rank: Rank.Four, name: 'Four of Spades' },
  { suit: Suit.Spades, rank: Rank.Five, name: 'Five of Spades' },
  { suit: Suit.Spades, rank: Rank.Six, name: 'Six of Spades' },
  { suit: Suit.Spades, rank: Rank.Seven, name: 'Seven of Spades' },
  { suit: Suit.Spades, rank: Rank.Eight, name: 'Eight of Spades' },
  { suit: Suit.Spades, rank: Rank.Nine, name: 'Nine of Spades' },
  { suit: Suit.Spades, rank: Rank.Ten, name: 'Ten of Spades' },
  { suit: Suit.Spades, rank: Rank.Jack, name: 'Jack of Spades' },
  { suit: Suit.Spades, rank: Rank.Queen, name: 'Queen of Spades' },
  { suit: Suit.Spades, rank: Rank.King, name: 'King of Spades' },
];


export function calculateSolarValue(month: number, day: number): number {
  // This equation produces a value from 0 (Dec 31) to 52 (Jan 1)
  return 55 - (2 * month + day);
}

export function mapValueToCard(value: number): Card {
  if (value < 0 || value > 52) {
    // This case shouldn't be reached with valid dates, but as a fallback.
    return { suit: Suit.Joker, rank: Rank.Joker, value, name: 'Invalid Value' };
  }
  const cardInfo = solarValueMap[value];
  return { ...cardInfo, value };
}

export function normalizeCardNameForKey(cardName: string): string {
    if (!cardName) return '';
    const rankMap: { [key: string]: string } = {
        'Two': '2', 'Three': '3', 'Four': '4', 'Five': '5', 'Six': '6', 
        'Seven': '7', 'Eight': '8', 'Nine': '9', 'Ten': '10'
    };
    const parts = cardName.split(' of ');
    if (parts.length !== 2) return cardName;

    const rankWord = parts[0];
    const suitWord = parts[1];
    
    if (rankMap[rankWord]) {
        return `${rankMap[rankWord]} of ${suitWord}`;
    }
    
    return cardName;
}

export function mapNameToCard(name: string): Card | null {
  if (name === 'None' || !name) {
    return null;
  }
  
  if (name === 'Joker') {
    return {
      suit: Suit.Joker,
      rank: Rank.Joker,
      value: 0,
      name: 'Joker',
    };
  }
  
  // Handle 'or', 'and' cases by taking the first card for visual representation
  const cardNameToParse = name.split(/ or | and /)[0];

  const parts = cardNameToParse.split(' of ');
  if (parts.length !== 2) {
    // Fallback for unexpected formats like "10 Diamonds"
     const rankMatch = cardNameToParse.match(/^(Ace|King|Queen|Jack|10|9|8|7|6|5|4|3|2)/i);
     const suitMatch = cardNameToParse.match(/(Hearts|Clubs|Diamonds|Spades)$/i);
     if (rankMatch && suitMatch) {
         return mapNameToCard(`${rankMatch[0]} of ${suitMatch[0]}`);
     }
    return { suit: Suit.Joker, rank: Rank.Joker, value: 0, name: name };
  }

  const rankStr = parts[0].trim();
  const suitStr = parts[1].trim();

  const rankMap: { [key: string]: Rank } = {
    'Ace': Rank.Ace, 
    '2': Rank.Two, 'Two': Rank.Two,
    '3': Rank.Three, 'Three': Rank.Three,
    '4': Rank.Four, 'Four': Rank.Four,
    '5': Rank.Five, 'Five': Rank.Five,
    '6': Rank.Six, 'Six': Rank.Six,
    '7': Rank.Seven, 'Seven': Rank.Seven,
    '8': Rank.Eight, 'Eight': Rank.Eight,
    '9': Rank.Nine, 'Nine': Rank.Nine,
    '10': Rank.Ten, 'Ten': Rank.Ten,
    'Jack': Rank.Jack, 
    'Queen': Rank.Queen, 
    'King': Rank.King,
  };

  const suitMap: { [key: string]: Suit } = {
    'Hearts': Suit.Hearts, 'Clubs': Suit.Clubs, 'Diamonds': Suit.Diamonds, 'Spades': Suit.Spades,
  };

  const rank = rankMap[rankStr] || Rank.Joker;
  const suit = suitMap[suitStr] || Suit.Joker;
  
  return { suit, rank, value: 0, name };
}

export function mapKeyToCard(key: string): Card {
  if (key === 'joker') {
    return { suit: Suit.Joker, rank: Rank.Joker, value: 0, name: 'Joker' };
  }
  
  const parts = key.split('_');
  if (parts.length !== 2) {
    return { suit: Suit.Joker, rank: Rank.Joker, value: 0, name: key };
  }

  const [rankStr, suitStr] = parts;

  const rankName = rankStr.charAt(0).toUpperCase() + rankStr.slice(1);
  const suitName = suitStr.charAt(0).toUpperCase() + suitStr.slice(1);

  const rankMap: { [key: string]: Rank } = {
    'Ace': Rank.Ace, 'Two': Rank.Two, 'Three': Rank.Three, 'Four': Rank.Four, 'Five': Rank.Five,
    'Six': Rank.Six, 'Seven': Rank.Seven, 'Eight': Rank.Eight, 'Nine': Rank.Nine, 'Ten': Rank.Ten,
    'Jack': Rank.Jack, 'Queen': Rank.Queen, 'King': Rank.King,
  };
  
  const suitMap: { [key: string]: Suit } = {
    'Hearts': Suit.Hearts, 'Clubs': Suit.Clubs, 'Diamonds': Suit.Diamonds, 'Spades': Suit.Spades,
  };

  const rank = rankMap[rankName] || Rank.Joker;
  const suit = suitMap[suitName] || Suit.Joker;
  
  let cardName = `${rankName} of ${suitName}`;
  if (rankName === "Ten") cardName = `10 of ${suitName}`;
  

  return { suit, rank, value: 0, name: cardName };
}


export function mapAbbreviationToCard(abbreviation: string): Card {
  if (!abbreviation) {
    return { suit: Suit.Joker, rank: Rank.Joker, value: 0, name: 'Unknown' };
  }
  
  const cleanedAbbr = abbreviation.replace(/\s+/g, '');

  const suitNames: { [key: string]: Suit } = {
      'Hearts': Suit.Hearts, 'Diamonds': Suit.Diamonds, 'Clubs': Suit.Clubs, 'Spades': Suit.Spades
  };
  let foundSuit: Suit | null = null;
  let rankStr: string | null = null;

  for (const suitKey of Object.keys(suitNames)) {
      if(cleanedAbbr.endsWith(suitKey)) {
          foundSuit = suitNames[suitKey];
          rankStr = cleanedAbbr.slice(0, -suitKey.length);
          break;
      }
  }

  if (!foundSuit || !rankStr) {
    // Fallback for 2-letter codes like 'AS'
    const suitChar = cleanedAbbr.slice(-1).toUpperCase();
    rankStr = cleanedAbbr.slice(0, -1);
    const suitMap: {[key: string]: Suit} = {'H': Suit.Hearts, 'D': Suit.Diamonds, 'C': Suit.Clubs, 'S': Suit.Spades };
    foundSuit = suitMap[suitChar] || Suit.Joker;
  }

  const rankMap: { [key: string]: Rank } = {
    'A': Rank.Ace, '2': Rank.Two, '3': Rank.Three, '4': Rank.Four, '5': Rank.Five,
    '6': Rank.Six, '7': Rank.Seven, '8': Rank.Eight, '9': Rank.Nine, '10': Rank.Ten,
    'J': Rank.Jack, 'Q': Rank.Queen, 'K': Rank.King,
  };
  const rank = rankMap[rankStr] || Rank.Joker;

  const rankNameMap: { [key: string]: string } = {
    'A': 'Ace', '2': '2', '3': '3', '4': '4', '5': '5',
    '6': '6', '7': '7', '8': '8', '9': '9', '10': '10',
    'J': 'Jack', 'Q': 'Queen', 'K': 'King',
  };
  const rankName = rankNameMap[rankStr] || 'Unknown';
  const name = `${rankName} of ${foundSuit}`;

  return { suit: foundSuit, rank, value: 0, name };
}

export function mapCardToKey(card: Card): string {
  if (card.rank === Rank.Joker) return 'joker';
  
  const rankMap: { [key in Rank]?: string } = {
    [Rank.Ace]: 'ace', [Rank.Two]: 'two', [Rank.Three]: 'three', [Rank.Four]: 'four', [Rank.Five]: 'five',
    [Rank.Six]: 'six', [Rank.Seven]: 'seven', [Rank.Eight]: 'eight', [Rank.Nine]: 'nine', [Rank.Ten]: 'ten',
    [Rank.Jack]: 'jack', [Rank.Queen]: 'queen', [Rank.King]: 'king'
  };
  
  const suitMap: { [key in Suit]?: string } = {
    [Suit.Hearts]: 'hearts', [Suit.Clubs]: 'clubs', [Suit.Diamonds]: 'diamonds', [Suit.Spades]: 'spades'
  };

  const rankStr = rankMap[card.rank];
  const suitStr = suitMap[card.suit];

  if (!rankStr || !suitStr) return 'joker'; // Fallback

  return `${rankStr}_${suitStr}`;
}
